# Task-master-app-using-Flask-Python-with-PostgreSQL
Developed a simple task management application using Flask, a micro web framework written in Python along with PostgreSQL and SQLAlchemy for database management.
